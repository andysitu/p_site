=====
WAREHOUSE MAP
=====

Requires warehouse_data.